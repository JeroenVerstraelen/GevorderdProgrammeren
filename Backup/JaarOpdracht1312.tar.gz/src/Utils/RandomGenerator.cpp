#include <stdlib.h>
#include <time.h>  
#include <iostream>
#include "RandomGenerator.h"

RandomGenerator* RandomGenerator::_instance = nullptr;

RandomGenerator* RandomGenerator::getInstance(){
	if(_instance == NULL){
		static RandomGenerator instance;
		_instance = &instance;
	}
 	return _instance;
}


int RandomGenerator::getRandomInt(int min, int max){
	srand (time(NULL));
	int random = rand();
	if(max != 0)
  		return rand() % max + min;
	return min;
}
