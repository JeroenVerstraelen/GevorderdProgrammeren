#include <SFML/Graphics.hpp>
#include <iostream>
#include "Controller/LevelController.h"
#include "View/LevelWindow.h"


int main(int argc, char *argv[]){
	if(argc == 2){
		// Create the window.
		LevelWindow level_window(sf::VideoMode(1200, 800), "Space Invaders");
		level_window.setPosition(sf::Vector2i(0, 0));

		// Create the main Game.
		LevelController level_controller(&level_window);
		level_controller.loadLevel("Resources/XMLDocuments/" + (std::string)argv[1] + ".xml");

		// Start the main Game.
		LevelStatus end_status = level_controller.startLevel();

		// Handle the end of the level.
		switch(end_status){
			case SUCCES: 
				break;
			case FAILURE: 
				break;
			default:
				break;
		}
	}
	else{
		std::cout << "./[program name] [XMLfile]" << std::endl;
	}
	return 0;
}
