#include <SFML/Graphics.hpp>
#include <vector>
#include <utility>
#include <stdexcept>
#include <iostream>

#include "LevelController.h"
#include "parsers/LevelParser.h"
#include "../View/LevelWindow.h"
#include "../View/Observer.h"
#include "../View/ParticleObserver.h"
#include "../Model/Level.h"
#include "../Model/Entity.h"
#include "../Model/Player.h"
#include "../Model/Bullet.h"
#include "../Model/Monster.h"
#include "../Utils/StopWatch.h"
#include "../Utils/RandomGenerator.h"


LevelController::LevelController(LevelWindow* lw) : level_window(lw){
	// Create a level with a default offset of 10% the y_bound.
	level = new Level(std::make_pair(lw->getSize().x, lw->getSize().y), 0.1 * lw->getSize().y);
	/*
	Observer observer(lw);
	ParticleObserver* p_ob = new ParticleObserver(&observer, 20000);
	std::vector<ParticleObserver*> p_obs = {p_ob};
	//ps = new ParticleGenerator(p_obs, 20000, CONTINUOUS);
	*/
}

LevelController::~LevelController(){
	delete level;
}

LevelStatus LevelController::startLevel(){
	// The StopWatch responsible for running the game at the same speed.
	StopWatch* stop_watch = StopWatch::getInstance();

	// run the program as long as the window is open
	while (level_window->isOpen())
	{
		// Reset the stop watch.
		stop_watch->reset();

		// clear the window with black color
		level_window->clear(sf::Color::Black);

		// Run the created level.
		LevelStatus current_status = this->tick(stop_watch);
		if(current_status != NORMAL) {
			level_window->close();
			return current_status;
		}

		// end the current frame
		level_window->display();
	}

	return FAILURE;
}

LevelStatus LevelController::tick(StopWatch* stop_watch){
	// The duration of the last tick.
	double elapsed_time = stop_watch->getPreviousTime();

	// Draw the background of the level.
	level_window->drawBackground();

	// Handle user input.
	sf::Event event;
	while (level_window->pollEvent(event))
	{
		switch (event.type)
		{
			// window closed
			case sf::Event::Closed:
		    		level_window->close();
		    		break;

			// key pressed
			case sf::Event::KeyPressed:
				if (event.key.code == sf::Keyboard::Escape){
		    			level_window->close();
				}
				else if (event.key.code == sf::Keyboard::Space){
					// Default 1 second between each shot.
					if(stop_watch->getPlayerBulletTime() >= 1000) {
						// Reset the bullet timer.
						stop_watch->resetPlayerBulletTime();
						// Shoot a bullet.
						Observer* bullet_observer = new Observer(level_window);
						try {
							bullet_observer->setTexture(level_window->getTextures().at("bullet"));
						}catch(std::out_of_range) {
							std::cerr << "Bullet texture file not found." << std::endl;
						}
						std::vector<Observer*> bullet_observers = {bullet_observer};
						Bullet* bullet = new Bullet(bullet_observers, level->getPlayer()->getLocation().first, level->getPlayer()->getLocation().second + 32, 16, 0, -1);
						bullet->setSenderType("player");
						level->addEntity(bullet);
					}
				}
			    	break;

			// other events
			default:
		    		break;
		}
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
   		level->getPlayer()->move(elapsed_time, level->getBounds().first, level->getBounds().second, LEFT);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
    		level->getPlayer()->move(elapsed_time, level->getBounds().first, level->getBounds().second, RIGHT);
	}

	/*
	// Particle Test
        ps->setEmitter(level->getPlayer()->getLocation().first, level->getPlayer()->getLocation().second);
        ps->update(elapsed_time);
	ps->notifyDraw();
	*/

	// Let the monster line shoot a bullet.
	RandomGenerator* rand_gen = RandomGenerator::getInstance();
	int rand_timer = rand_gen->getRandomInt(1000, 5000);
	if(stop_watch->getMonsterBulletTime() > rand_timer) {
		// Reset the timer for next time.
		stop_watch->resetMonsterBulletTime();

		// Create the bullet to shoot.
		Observer* bullet_observer = new Observer(level_window);
		try {
			bullet_observer->setTexture(level_window->getTextures().at("bullet"));
		}catch(std::out_of_range) {
			std::cerr << "Bullet texture file not found." << std::endl;
		}
		std::vector<Observer*> bullet_observers = {bullet_observer};
		Bullet* bullet = new Bullet(bullet_observers, 0, 0, 16, 0, 1);
		bullet->setSenderType("monster");
	
		std::vector<MonsterLine*> monster_lines = level->getMonsterLines();
		int r_index = rand_gen->getRandomInt(0, monster_lines.size() - 1);		
	
		level->addEntity(bullet);
		if(monster_lines[r_index] != NULL)
			monster_lines[r_index]->shoot(bullet);
	}

	// Handle AI.
	return level->tick(stop_watch);
}

bool LevelController::loadLevel(std::string file){
	LevelParser parser;
	try {
		parser.parseLevel(file, level, level_window);
	}catch(std::exception& e) {
		std::cerr << "Exception caught while loading level from XML file: " << e.what() << std::endl;
	    	std::terminate();
	}		

	return true;
}
