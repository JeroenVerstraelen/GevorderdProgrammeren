#include "ParticleObserver.h"

ParticleObserver::ParticleObserver(Observer* other, int count) : Observer(other->getLevelWindow()), _m_vertices(sf::Points, count)
{
}

void ParticleObserver::notify(ParticleGenerator* particle_generator, Notification n) {
	switch(n){
		case MOVE: 
		{
			std::vector<Particle> particles = particle_generator->getParticles();

			for (std::size_t i = 0; i < particles.size(); ++i)
			{
				_m_vertices[i].position = sf::Vector2f(particles[i].position.first, particles[i].position.second);
				_m_vertices[i].color.r = static_cast<sf::Uint8>(200);
				_m_vertices[i].color.g = static_cast<sf::Uint8>(50);
				_m_vertices[i].color.b = static_cast<sf::Uint8>(0);
			}
			break;
		}
	    	case DRAW: 
		{	
			level_window->draw(_m_vertices);
			break;
		}
		default:
		{
			break;
		}
	}
}
