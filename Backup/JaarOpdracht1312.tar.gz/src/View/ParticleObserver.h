#include "Observer.h"
#include "../Model/ParticleGenerator.h"

#ifndef PARTICLEOBSERVER_H_
#define PARTICLEOBSERVER_H_

class ParticleGenerator;

class ParticleObserver : public Observer {
private:

	/** 
	 * The VertexArray representing the particles.
	 */
	sf::VertexArray _m_vertices;

public:

	/** 
	 * Constructor
	 * @param observer Another observer responsible for creating the particles.
	 * @param count The amount of particles to observe.
	 */	
	ParticleObserver(Observer* other, int count);

	/**
	 * Notifies the observer of a given action by an observee.
	 * @param particle_generator The particle generator to observe.
	 * @param n An enum type detailing the action.
	 */
	void notify(ParticleGenerator* particle_generator, Notification n);
};

#endif /* PARTICLEOBSERVER_H_ */
