#include <SFML/Graphics.hpp>
#include <vector>
#include <algorithm>
#include <map>
#include <utility>

#include "Level.h"
#include "Entity.h"
#include "Player.h"
#include "../Utils/StopWatch.h"
#include "../Utils/RandomGenerator.h"

Level::Level(std::pair<double, double> bounds, double y_offset) : _bounds(bounds), _y_offset(y_offset) {}

Level::~Level(){
	for(auto &entity : _entities)
		delete entity;
}

LevelStatus Level::tick(StopWatch* stop_watch){
	double elapsed_time = stop_watch->getPreviousTime();

	// The entities to remove after the AI has been handled.
	std::vector<Entity*> entities_to_remove;

	// Handle AI.
	for(auto &entity : _entities) {
		// Monsters
		if(entity->getType() == "MonsterLine"){
			// Default move the monster line each second.
			if(stop_watch->getMonsterTime() >= 1000) {
				if(!entity->move(elapsed_time, _bounds.first, _bounds.second - _y_offset))
					return FAILURE;	
			}
		}

		// Bullets
		if(entity->getType() == "Bullet") {
			if(!entity->move(elapsed_time, _bounds.first, _bounds.second)){
				entities_to_remove.push_back(entity);
				continue;
			}
			for(auto &other : _entities) {
				if(entity != other){
					bool delete_bullet = false;
					if(other->checkCollisionDeath(entity, delete_bullet))
						entities_to_remove.push_back(other);
					if(delete_bullet)
						entities_to_remove.push_back(entity);
				}
			}
		}
	}

	// Reset the monster move timer.
	if(stop_watch->getMonsterTime() >= 1000)
		stop_watch->resetMonsterTime();	


	// Remove the entities that have been killed by a bullet.
	for(auto &entity : entities_to_remove) {
		if(entity != NULL){
			std::vector<Entity*>::iterator it = std::find(_entities.begin(), _entities.end(), entity);
			if(it != _entities.end()) {
				if(entity == _player)
					return FAILURE;
				std::vector<MonsterLine*>::iterator monsterl_it = std::find(_monster_lines.begin(), _monster_lines.end(), entity);
				if(monsterl_it != _monster_lines.end())
					_monster_lines.erase(monsterl_it);
				_entities.erase(it);
				delete entity;
			}
		}
	}	

	// Check if there are any monsters left.
	bool monsters_left = false;
	for(auto &entity : _entities){
		if(entity->getType() == "MonsterLine") {
			monsters_left = true;
			break;
		}
	}
	if(!monsters_left)
		return SUCCES;


	// Notify all to draw
	for(auto &entity : _entities)
		entity->notifyDraw(); 

	return NORMAL;
}

void Level::setPlayer(Player* p){
	_player = p;
}

void Level::setYOffset(double offset){
	_y_offset = offset;
}

void Level::setBounds(std::pair<double, double> bounds){
	_bounds = bounds;
}

void Level::addEntity(Entity* entity){
	_entities.push_back(entity);

	if(entity->getType() == "MonsterLine"){
		MonsterLine* monster_line = static_cast<MonsterLine*>(entity);
		_monster_lines.push_back(monster_line);
	}
}

Player* Level::getPlayer() const {
	return _player;
}

std::vector<MonsterLine*> Level::getMonsterLines() const {
	return _monster_lines;
}

std::pair<double, double> const Level::getBounds() const {
	return _bounds;
}


