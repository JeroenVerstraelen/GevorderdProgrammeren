#include <limits>
#include <list>
#include <algorithm>
#include <stdlib.h> 
#include <stdexcept>
#include "Entity.h"
#include "MonsterLine.h"
#include "Bullet.h"
#include "../Utils/RandomGenerator.h"
#include "../View/ParticleObserver.h"

MonsterLine::MonsterLine(Direction direction, double x_speed, double y_speed, double x_bound, double x_buffer, std::vector<Entity*> monsters) : _direction(direction), _monsters(monsters)
{
	_x_speed = x_speed;
	_y_speed = y_speed;
	_x_buffer = x_buffer;

	// Calculate the size of the line.
	double max_x = 0;
	double min_x = std::numeric_limits<double>::infinity();
	for(auto &monster : _monsters) {
		if(monster->getLocation().first > max_x) {
			max_x = monster->getLocation().first;
		}
		if(monster->getLocation().first < min_x) {
			min_x = monster->getLocation().first;
		}
	}
	_line_size = max_x - min_x;
	
	// Calculate the location of the line.
	_x = max_x;	
	_y = _monsters.front()->getLocation().second;
}

MonsterLine::~MonsterLine(){
	for(auto &monster: _monsters)
		delete monster;
}

void MonsterLine::addMonster(Entity* monster) {
	_monsters.push_back(monster);

	// Recalculate the size of the line.
	double max_x = 0;
	double min_x = std::numeric_limits<double>::infinity();
	for(auto &monster : _monsters) {
		if(monster->getLocation().first > max_x) {
			max_x = monster->getLocation().first;
		}
		if(monster->getLocation().first < min_x) {
			min_x = monster->getLocation().first;
		}
	}
	_line_size = max_x - min_x;
	_x = max_x;
}

bool MonsterLine::deleteMonster(Entity* entity) {
	std::vector<Entity*>::iterator it = std::find(_monsters.begin(), _monsters.end(), entity);
	if(it != _monsters.end()) {
		ParticleObserver* p_obs = new ParticleObserver(entity->getObservers().front(), 10000);
		std::vector<ParticleObserver*> particle_observers = {p_obs};
		ParticleGenerator* p_gen = new ParticleGenerator(particle_observers, 10000, EXPLOSION);
		p_gen->setEmitter(entity->getLocation().first, entity->getLocation().second);
		_particle_generators.push_back(p_gen);
		_monsters.erase(it);
		delete entity;
	}
	// Line_size will remain the same after deletion.
	// Recalculate the size of the line.
	double max_x = 0;
	double min_x = std::numeric_limits<double>::infinity();
	for(auto &monster : _monsters) {
		if(monster->getLocation().first > max_x) {
			max_x = monster->getLocation().first;
		}
		if(monster->getLocation().first < min_x) {
			min_x = monster->getLocation().first;
		}
	}
	_line_size = max_x - min_x;
	_x = max_x;

	return _monsters.empty();
}

std::string MonsterLine::getType(){
	return "MonsterLine";
}

bool MonsterLine::move(double elapsed_time, double x_bound, double y_bound, Direction direction) {
	double x_delta = _x_speed;
	double y_delta = 0;
	if(_direction == RIGHT) {
		x_delta = _x_speed;
		if(_x + x_delta > x_bound - _x_buffer){
			x_delta = 0;
			y_delta = _y_speed;
			_direction = LEFT;
		}
	}
	else if (_direction == LEFT) {
		x_delta = -_x_speed;
		if((_x + x_delta) - _line_size <= 0) {
			x_delta = 0;
			y_delta = _y_speed;
			_direction = RIGHT;
		}
	}
	_x += x_delta;
	_y += y_delta;

	// Move all the entities.
	for(auto &monster : _monsters)
		monster->move(x_delta, y_delta, x_bound, y_bound);

	if(_monsters.front()->getLocation().second >= y_bound){
		// Level has ended.
		return false;
	}

	return true;
}

void MonsterLine::shoot(Bullet* bullet) {
	// Generate a random index.
	RandomGenerator* rand_gen = RandomGenerator::getInstance();
	int rand_index = rand_gen->getRandomInt(0, _monsters.size()-1);

	// Shoot the bullet.
	bullet->setLocation(_monsters.at(rand_index)->getLocation().first, _monsters.at(rand_index)->getLocation().second);
}

bool MonsterLine::checkCollisionDeath(Entity* entity, bool& delete_other) {
	for(auto &monster : _monsters){
		if(monster->checkCollisionDeath(entity, delete_other)){
			delete_other = true;
			return deleteMonster(monster);
		}
	}
	return false;
}


void MonsterLine::notifyDraw(){
	for(auto &monster : _monsters) {
		monster->notifyDraw();
	}

	std::vector<ParticleGenerator*> p_gen_to_remove;
	for(auto p_gen : _particle_generators) {
		if(!p_gen->update(16)) 
			p_gen_to_remove.push_back(p_gen);
		p_gen->notifyDraw();
	}

	for(auto p_gen : p_gen_to_remove) {
		std::vector<ParticleGenerator*>::iterator it = std::find(_particle_generators.begin(), _particle_generators.end(), p_gen);
		if(it != _particle_generators.end()) {
			_particle_generators.erase(it);		
			delete p_gen;
		}
	}
}
